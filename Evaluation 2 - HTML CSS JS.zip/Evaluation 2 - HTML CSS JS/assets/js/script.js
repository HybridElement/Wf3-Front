$(function() {
    $('#adoption').on('submit', function(e) {
    e.preventDefault();
});
});
// test
console.log("hey");